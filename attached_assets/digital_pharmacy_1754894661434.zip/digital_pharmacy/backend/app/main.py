# backend/app/main.py

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from sqlalchemy.orm import Session
from . import models, crud, schemas
from .database import SessionLocal, engine

# Create the database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# New health check endpoint
@app.get("/health")
def health_check():
    """Endpoint for health checking the API service."""
    return {"status": "ok"}

@app.get("/api/medicines/search", response_model=List[schemas.Medicine])
def search_medicines(q: str, db: Session = Depends(get_db)):
    """Search for medicines by title or manufacturer."""
    if not q:
        raise HTTPException(status_code=400, detail="Query parameter 'q' is required.")
    medicines = crud.search_medicines(db=db, query=q)
    if not medicines:
        raise HTTPException(status_code=404, detail="No medicines found.")
    return medicines

@app.post("/api/pharmacies/", response_model=schemas.Pharmacy)
def create_pharmacy(pharmacy: schemas.PharmacyCreate, db: Session = Depends(get_db)):
    """Create a new pharmacy."""
    return crud.create_pharmacy(db=db, pharmacy=pharmacy)

@app.get("/api/pharmacies/", response_model=List[schemas.Pharmacy])
def get_pharmacies(db: Session = Depends(get_db)):
    """Get a list of all pharmacies."""
    pharmacies = crud.get_pharmacies(db=db)
    return pharmacies
