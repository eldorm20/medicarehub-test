# backend/load_meds.py
import json
import os
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Text
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", f"postgresql://{os.getenv('POSTGRES_USER')}:{os.getenv('POSTGRES_PASSWORD')}@{os.getenv('POSTGRES_HOST')}:{os.getenv('POSTGRES_PORT')}/{os.getenv('POSTGRES_DB')}")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
metadata = MetaData()

medicines_table = Table(
    "medicines",
    metadata,
    Column("id", Integer, primary_key=True, index=True),
    Column("trade_name", String, index=True),
    Column("company", String),
    Column("composition", Text),
    Column("pharmacotherapeutic_group", String),
    Column("atx_code", String),
    Column("release_form", String),
)

def init_db():
    metadata.create_all(bind=engine)

def load_data():
    if not os.path.exists("app/uzpharm_all_medicines.json"):
        print("uzpharm_all_medicines.json not found. Skipping data load.")
        return

    db = SessionLocal()
    try:
        # Check if table is already populated
        from sqlalchemy import text
        count_result = db.execute(text("SELECT COUNT(*) FROM medicines")).scalar()
        if count_result > 0:
            print("Medicines table is already populated. Skipping data load.")
            return

        with open("app/uzpharm_all_medicines.json", "r") as f:
            data = json.load(f)
        
        print(f"Loading {len(data)} medicines...")
        for item in data:
            db.execute(
                medicines_table.insert().values(
                    trade_name=item.get("title", ""),
                    company=item.get("manufacturer", ""),
                    composition=item.get("title_2", ""), # Assuming title_2 contains composition
                    pharmacotherapeutic_group=None, # This data is not in the JSON, can be added later
                    atx_code=None, # This data is not in the JSON, can be added later
                    release_form=None, # This data is not in the JSON, can be added later
                )
            )
        db.commit()
        print("Data loaded successfully.")
    except Exception as e:
        print(f"Error loading data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    init_db()
    load_data()
