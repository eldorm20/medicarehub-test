# importer.py
# This script will be run once by the 'importer' service to seed the database.

import json
import os
import time
import psycopg2
from psycopg2.extras import DictCursor

DATABASE_URL = os.getenv("DATABASE_URL")
# Corrected path to the JSON file
DATA_FILE = "/app/uzpharm_all_medicines.json"

def create_tables(conn):
    """Creates the necessary tables in the database."""
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS medicines (
                id SERIAL PRIMARY KEY,
                original_id VARCHAR(255) UNIQUE,
                title TEXT NOT NULL,
                country TEXT,
                manufacturer TEXT,
                reg_num TEXT
            );
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS pharmacies (
                id SERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                address TEXT NOT NULL,
                latitude DOUBLE PRECISION,
                longitude DOUBLE PRECISION
            );
        """)
        conn.commit()

def import_data(conn):
    """Imports medicine data from the JSON file into the database."""
    print("Starting data import...")
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    with conn.cursor() as cur:
        for item in data:
            try:
                cur.execute(
                    """
                    INSERT INTO medicines (original_id, title, country, manufacturer, reg_num)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (original_id) DO NOTHING;
                    """,
                    (item.get("DT_RowId"), item.get("title"), item.get("country"), item.get("manufacturer"), item.get("reg_num"))
                )
            except psycopg2.Error as e:
                print(f"Error inserting item with original_id {item.get('DT_RowId')}: {e}")
        conn.commit()
    print("Data import finished.")

def main():
    """Main function to connect to the database and import data."""
    conn = None
    max_retries = 10
    retries = 0
    while retries < max_retries:
        try:
            print(f"Attempting to connect to the database... (Attempt {retries + 1}/{max_retries})")
            conn = psycopg2.connect(DATABASE_URL)
            print("Database connection successful!")
            break
        except psycopg2.OperationalError as e:
            print(f"Database connection failed: {e}")
            retries += 1
            time.sleep(5)

    if conn is None:
        print("Failed to connect to the database after multiple retries. Exiting.")
        return

    try:
        create_tables(conn)
        import_data(conn)
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    main()
