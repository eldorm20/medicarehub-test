# bot/bot.py
import os
import logging
import io
import json
import httpx
from typing import Dict, Any, List

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    ConversationHandler,
    CallbackQueryHandler,
    filters,
)

# -------------------------
# Config & logging
# -------------------------
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")

if not TELEGRAM_BOT_TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN is not set.")

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(name)s - %(message)s"
)
logger = logging.getLogger("digital_pharmacy_bot")

# -------------------------
# Conversation states & callbacks
# -------------------------
REGISTER_NAME, REGISTER_PHONE = range(2)
AWAITING_PRESCRIPTION = 3
AWAITING_SEARCH_QUERY = 4
AWAITING_QUANTITY = 5
CHOOSE_DELIVERY_METHOD = 6
AWAITING_DELIVERY_LOCATION = 7
CHOOSE_PHARMACY_PICKUP = 8

# Callback data prefixes for inline buttons
CALLBACK_SEARCH = "search"
CALLBACK_UPLOAD_PRESCRIPTION = "upload_prescription"
CALLBACK_CART = "cart"
CALLBACK_CHECKOUT = "checkout"
CALLBACK_PROFILE = "profile"
CALLBACK_SETTINGS = "settings"
CALLBACK_NEXT_PAGE = "next_page"
CALLBACK_PREV_PAGE = "prev_page"
CALLBACK_ADD_ITEM = "add_item"
CALLBACK_REMOVE_ITEM = "remove_item"
CALLBACK_SET_QTY = "set_qty"
CALLBACK_BACK_TO_MENU = "back_to_menu"
CALLBACK_DELIVERY = "delivery"
CALLBACK_PICKUP = "pickup"
CALLBACK_SELECT_PHARMACY = "select_pharmacy"

# -------------------------
# Utilities
# -------------------------
async def get_http_client(app: Application) -> httpx.AsyncClient:
    """Return a cached AsyncClient stored on application."""
    client = app.bot_data.get("http_client")
    if client is None:
        client = httpx.AsyncClient(base_url=BACKEND_URL, timeout=10.0)
        app.bot_data["http_client"] = client
    return client

def create_main_menu_keyboard():
    """Creates the main menu inline keyboard."""
    keyboard = [
        [
            InlineKeyboardButton("🔎 Найти лекарство", callback_data=CALLBACK_SEARCH),
        ],
        [
            InlineKeyboardButton("📝 Загрузить рецепт", callback_data=CALLBACK_UPLOAD_PRESCRIPTION),
        ],
        [
            InlineKeyboardButton("🛒 Корзина", callback_data=CALLBACK_CART),
            InlineKeyboardButton("👤 Мой профиль", callback_data=CALLBACK_PROFILE),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)

def create_search_results_keyboard(medicines: List[Dict], page: int = 0):
    """Creates an inline keyboard for paginated search results with 'add' buttons."""
    keyboard = []
    keyboard.append([InlineKeyboardButton("⬅️ Главное меню", callback_data=CALLBACK_BACK_TO_MENU)])
    for med in medicines:
        keyboard.append([
            InlineKeyboardButton(
                f"➕ Добавить {med['title']}",
                callback_data=f"{CALLBACK_ADD_ITEM}_{med['id']}"
            )
        ])

    pagination_buttons = []
    if page > 0:
        pagination_buttons.append(InlineKeyboardButton("⬅️ Назад", callback_data=f"{CALLBACK_PREV_PAGE}_{page-1}"))
    if len(medicines) == 5: # Assuming a page size of 5 for demonstration
        pagination_buttons.append(InlineKeyboardButton("➡️ Вперёд", callback_data=f"{CALLBACK_NEXT_PAGE}_{page+1}"))
    if pagination_buttons:
        keyboard.append(pagination_buttons)

    return InlineKeyboardMarkup(keyboard)

def create_quantity_keyboard(product_id):
    """Creates an inline keyboard for quantity selection."""
    keyboard = [
        [
            InlineKeyboardButton("1", callback_data=f"{CALLBACK_SET_QTY}_{product_id}_1"),
            InlineKeyboardButton("2", callback_data=f"{CALLBACK_SET_QTY}_{product_id}_2"),
            InlineKeyboardButton("5", callback_data=f"{CALLBACK_SET_QTY}_{product_id}_5"),
        ],
        [
            InlineKeyboardButton("10", callback_data=f"{CALLBACK_SET_QTY}_{product_id}_10"),
            InlineKeyboardButton("❌ Отмена", callback_data=CALLBACK_CART)
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_delivery_options_keyboard():
    """Creates a keyboard for choosing delivery or pickup."""
    keyboard = [
        [
            InlineKeyboardButton("🚚 Доставка", callback_data=CALLBACK_DELIVERY),
        ],
        [
            InlineKeyboardButton("🚶 Самовывоз из аптеки", callback_data=CALLBACK_PICKUP),
        ],
        [
            InlineKeyboardButton("❌ Отмена", callback_data=CALLBACK_BACK_TO_MENU)
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_pharmacy_pickup_keyboard(pharmacies: List[Dict]):
    """Creates a keyboard for choosing a pickup pharmacy."""
    keyboard = []
    for pharmacy in pharmacies:
        keyboard.append([
            InlineKeyboardButton(
                f"{pharmacy['name']} - {pharmacy['address']}",
                callback_data=f"{CALLBACK_SELECT_PHARMACY}_{pharmacy['id']}"
            )
        ])
    keyboard.append([InlineKeyboardButton("❌ Отмена", callback_data=CALLBACK_BACK_TO_MENU)])
    return InlineKeyboardMarkup(keyboard)


# -------------------------
# Handlers
# -------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Greets the user and shows the main menu."""
    user = update.effective_user
    text = (
        f"👋 Привет, {user.first_name}!\n\n"
        "Я — бот Digital Pharmacy. Я могу помочь тебе с заказом лекарств, "
        "поиском по базе и отправкой рецептов.\n\n"
        "Выберите действие из меню ниже:"
    )
    reply_markup = create_main_menu_keyboard()
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, reply_markup=reply_markup)
    return ConversationHandler.END


# --- Medicine search ---
async def search_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Starts the search conversation. This is called from a CallbackQuery handler, so 'update' is a CallbackQuery object."""
    # The 'update' object here is a CallbackQuery, which does not have `effective_chat`.
    # We must get the chat_id from the message object associated with the callback.
    await context.bot.send_message(chat_id=update.message.chat_id, text="Введите название лекарства для поиска:")
    return AWAITING_SEARCH_QUERY

async def handle_search_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles a search query and displays results with inline buttons."""
    query = update.message.text.strip()
    context.user_data['last_search_query'] = query

    await display_search_results(update, context, query, page=0)
    return ConversationHandler.END

async def display_search_results(update: Update, context: ContextTypes.DEFAULT_TYPE, query: str, page: int):
    """Fetches and displays a specific page of search results."""
    client = await get_http_client(context.application)
    try:
        r = await client.get("/api/medicines/search", params={"q": query, "page": page})
        r.raise_for_status()
        medicines = r.json()

        if not medicines and page == 0:
            await update.message.reply_text("Ничего не найдено. Попробуйте другой запрос.")
            return

        text = f"🔎 Результаты поиска для '{query}':\n\n"
        for med in medicines:
            text += f"**{med['title']}** (ID: {med['id']})\n"
            text += f"Производитель: {med['manufacturer']}\n\n"

        reply_markup = create_search_results_keyboard(medicines, page)

        if update.callback_query:
            await update.callback_query.edit_message_text(text, parse_mode="Markdown", reply_markup=reply_markup)
        else:
            await update.message.reply_text(text, parse_mode="Markdown", reply_markup=reply_markup)

    except Exception:
        logger.exception("Failed to search medicines")
        await context.bot.send_message(chat_id=update.effective_chat.id, text="Не удалось выполнить поиск. Попробуйте позже.")


# --- Cart & Ordering ---
async def view_cart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fetches and displays the user's cart with interactive buttons."""
    user_id = str(update.effective_user.id)
    client = await get_http_client(context.application)
    try:
        r = await client.get(f"/api/cart/{user_id}")
        r.raise_for_status()
        cart = r.json()
        if not cart.get("items"):
            await context.bot.send_message(chat_id=update.effective_chat.id, text="Ваша корзина пуста.")
            return

        text_lines = ["🛒 **Ваша корзина:**"]
        keyboard = []
        for it in cart["items"]:
            text_lines.append(f"- {it['name']} x{it['quantity']} (ID: {it['product_id']})")
            keyboard.append([
                InlineKeyboardButton(f"➖ Удалить {it['name']}", callback_data=f"{CALLBACK_REMOVE_ITEM}_{it['product_id']}"),
            ])

        text_lines.append("\n✅ Готовы оформить заказ?")
        keyboard.append([InlineKeyboardButton("✅ Оформить заказ", callback_data=CALLBACK_CHECKOUT)])
        keyboard.append([InlineKeyboardButton("⬅️ Главное меню", callback_data=CALLBACK_BACK_TO_MENU)])

        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(chat_id=update.effective_chat.id, text="\n".join(text_lines), parse_mode="Markdown", reply_markup=reply_markup)
    except Exception:
        logger.exception("Failed to fetch cart")
        await context.bot.send_message(chat_id=update.effective_chat.id, text="Не удалось получить корзину — попробуйте позже.")

async def checkout_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Starts the checkout conversation by asking for delivery method."""
    await update.callback_query.edit_message_text(
        "Как вы хотите получить ваш заказ?",
        reply_markup=create_delivery_options_keyboard()
    )
    return CHOOSE_DELIVERY_METHOD

async def choose_delivery(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Asks the user for their delivery location."""
    await update.callback_query.edit_message_text(
        "Пожалуйста, отправьте мне свое местоположение.",
        reply_markup=ReplyKeyboardMarkup(
            [[KeyboardButton("📍 Отправить местоположение", request_location=True)]],
            one_time_keyboard=True,
            resize_keyboard=True,
        )
    )
    return AWAITING_DELIVERY_LOCATION

async def handle_delivery_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the user's location and creates the order."""
    location = update.message.location
    if not location:
        await update.message.reply_text("Пожалуйста, отправьте свое местоположение.")
        return AWAITING_DELIVERY_LOCATION

    user_id = str(update.effective_user.id)
    client = await get_http_client(context.application)
    payload = {
        "telegram_id": user_id,
        "delivery_method": "delivery",
        "address": {
            "latitude": location.latitude,
            "longitude": location.longitude
        }
    }

    try:
        r = await client.post("/api/orders/create", json=payload)
        r.raise_for_status()
        j = r.json()
        order_id = j.get("order_id")
        # In a real app, you would get a payment link here
        await update.message.reply_text(f"Заказ на доставку создан ✅\nOrder ID: {order_id}\nОжидайте оплату.")
    except Exception:
        logger.exception("Failed to create delivery order")
        await update.message.reply_text("Ошибка при оформлении заказа на доставку. Попробуйте позже.")

    return ConversationHandler.END


async def choose_pickup_pharmacy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fetches pharmacies and lets the user choose one."""
    client = await get_http_client(context.application)
    try:
        r = await client.get("/api/pharmacies")
        r.raise_for_status()
        pharmacies = r.json()

        reply_markup = create_pharmacy_pickup_keyboard(pharmacies)
        await update.callback_query.edit_message_text("Выберите аптеку для самовывоза:", reply_markup=reply_markup)
    except Exception:
        logger.exception("Failed to fetch pharmacies")
        await update.callback_query.edit_message_text("Не удалось получить список аптек. Попробуйте позже.", reply_markup=create_main_menu_keyboard())

    return CHOOSE_PHARMACY_PICKUP

async def handle_pickup_pharmacy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the user's pharmacy choice and creates the order."""
    query = update.callback_query
    pharmacy_id = int(query.data.split('_')[-1])
    user_id = str(update.effective_user.id)
    client = await get_http_client(context.application)
    payload = {
        "telegram_id": user_id,
        "delivery_method": "pickup",
        "pharmacy_id": pharmacy_id
    }

    try:
        r = await client.post("/api/orders/create", json=payload)
        r.raise_for_status()
        j = r.json()
        order_id = j.get("order_id")
        await query.edit_message_text(f"Заказ на самовывоз создан ✅\nOrder ID: {order_id}\nОжидайте подтверждения от аптеки.")
    except Exception:
        logger.exception("Failed to create pickup order")
        await query.edit_message_text("Ошибка при оформлении заказа. Попробуйте позже.", reply_markup=create_main_menu_keyboard())

    return ConversationHandler.END

# --- Placeholder handlers for missing functions ---
async def register_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Начало регистрации.")
    return ConversationHandler.END

async def register_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Зарегистрировано имя.")
    return ConversationHandler.END

async def register_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Зарегистрирован телефон.")
    return ConversationHandler.END

async def register_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Регистрация отменена.")
    return ConversationHandler.END

async def upload_prescription_entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Отправьте фотографию или скан рецепта.")
    return ConversationHandler.END

async def handle_prescription_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Рецепт получен и будет обработан.")
    return ConversationHandler.END

async def view_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(chat_id=update.effective_chat.id, text="Профиль пользователя.")
    return ConversationHandler.END

async def add_item_to_cart_with_qty(query, context, product_id, quantity):
    await context.bot.send_message(chat_id=query.effective_chat.id, text=f"Adding {quantity} of product {product_id} to cart.")

async def remove_item_from_cart(query, context, product_id):
    await context.bot.send_message(chat_id=query.effective_chat.id, text=f"Removing product {product_id} from cart.")

# --- Callback query handler for inline buttons ---
async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles button presses from inline keyboards."""
    query = update.callback_query
    await query.answer()

    data = query.data
    logger.info(f"Received callback query with data: {data}")

    # Main menu actions
    if data == CALLBACK_BACK_TO_MENU:
        await start(query, context)
        return
    elif data == CALLBACK_SEARCH:
        await search_start(query, context)
        return
    elif data == CALLBACK_UPLOAD_PRESCRIPTION:
        await upload_prescription_entry(query, context)
        return
    elif data == CALLBACK_CART:
        await view_cart(query, context)
        return
    elif data == CALLBACK_PROFILE:
        await view_profile(query, context)
        return
    elif data == CALLBACK_CHECKOUT:
        await checkout_start(query, context)
        return

    # Search & Pagination actions
    if data.startswith(CALLBACK_NEXT_PAGE) or data.startswith(CALLBACK_PREV_PAGE):
        page = int(data.split('_')[-1])
        query_text = context.user_data.get('last_search_query', '')
        if query_text:
            await display_search_results(query, context, query_text, page)
        else:
            await query.edit_message_text("Поиск не найден. Пожалуйста, начните новый поиск.")
        return

    # Add item flow
    elif data.startswith(CALLBACK_ADD_ITEM):
        product_id = data.split('_')[-1]
        context.user_data['product_id_to_add'] = product_id
        await query.edit_message_text("Пожалуйста, выберите количество:", reply_markup=create_quantity_keyboard(product_id))
        return

    elif data.startswith(CALLBACK_SET_QTY):
        parts = data.split('_')
        product_id = parts[-2]
        quantity = int(parts[-1])
        await add_item_to_cart_with_qty(query, context, product_id, quantity)
        await query.edit_message_text("✅ Товар добавлен в корзину.")
        await start(query, context)
        return

    # Cart actions
    elif data.startswith(CALLBACK_REMOVE_ITEM):
        product_id = data.split('_')[-1]
        await remove_item_from_cart(query, context, product_id)
        return

    await query.edit_message_text("Неизвестная команда. Вернитесь в меню.", reply_markup=create_main_menu_keyboard())


# --- Misc ---
async def unknown(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Responds to unknown commands."""
    await update.message.reply_text("Я пока не понимаю эту команду. Используйте /start чтобы увидеть опции.")


# -------------------------
# App setup
# -------------------------
def main():
    """Main function to run the bot."""
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Register conversation handlers
    checkout_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(checkout_start, pattern="^checkout$")],
        states={
            CHOOSE_DELIVERY_METHOD: [
                CallbackQueryHandler(choose_delivery, pattern="^delivery$"),
                CallbackQueryHandler(choose_pickup_pharmacy, pattern="^pickup$"),
            ],
            AWAITING_DELIVERY_LOCATION: [MessageHandler(filters.LOCATION, handle_delivery_location)],
            CHOOSE_PHARMACY_PICKUP: [CallbackQueryHandler(handle_pickup_pharmacy, pattern="^select_pharmacy_")],
        },
        fallbacks=[CallbackQueryHandler(start, pattern="^back_to_menu$"), CommandHandler("start", start)],
        name="checkout_conv",
        persistent=False,
    )
    application.add_handler(checkout_conv)

    reg_conv = ConversationHandler(
        entry_points=[CommandHandler("register", register_start)],
        states={
            REGISTER_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, register_name)],
            REGISTER_PHONE: [MessageHandler((filters.CONTACT | (filters.TEXT & ~filters.COMMAND)), register_phone)],
        },
        fallbacks=[CommandHandler("cancel", register_cancel)],
        name="registration_conv",
        persistent=False,
    )
    application.add_handler(reg_conv)

    pres_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(upload_prescription_entry, pattern="^upload_prescription$")],
        states={
            AWAITING_PRESCRIPTION: [MessageHandler(filters.Document.ALL | filters.PHOTO, handle_prescription_file)]
        },
        fallbacks=[CommandHandler("cancel", register_cancel)],
        name="prescription_conv",
        persistent=False,
    )
    application.add_handler(pres_conv)

    search_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(search_start, pattern="^search$")],
        states={
            AWAITING_SEARCH_QUERY: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_search_query)]
        },
        fallbacks=[CallbackQueryHandler(start, pattern="^back_to_menu$")],
        name="search_conv",
        persistent=False,
    )
    application.add_handler(search_conv)

    # Register other handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("cart", view_cart))
    application.add_handler(CommandHandler("profile", view_profile))

    # Handle inline keyboard button presses
    application.add_handler(CallbackQueryHandler(handle_callback_query))

    application.add_handler(MessageHandler(filters.COMMAND, unknown))

    logger.info("Starting Digital Pharmacy Telegram bot...")
    application.run_polling(poll_interval=1.0)

if __name__ == "__main__":
    main()
